using System;

namespace recursividad
{
    public class EjercicioMCD
    {
        public int CalcularMCD(int a, int b)
        {
            if (b == 0)
            {
                return a;
            }
            return CalcularMCD(b, a % b);
        }
    }
}

using System;

namespace Utilities
{
    public static class ConsoleUtils
    {
        public static void Escribir(string mensaje)
        {
            Console.WriteLine(mensaje);
        }

        public static int LeerNumero(string mensaje)
        {
            int numero;
            bool valido = false;

            do
            {
                Escribir(mensaje);
                string input = Console.ReadLine()!;

                if (int.TryParse(input, out numero))
                {
                    valido = true;
                }
                else
                {
                    Escribir("Entrada no válida. Por favor, introduzca un número entero.");
                }
            } while (!valido);

            return numero;
        }

        public static decimal LeerDecimal(string mensaje)
        {
            decimal numero;
            bool valido = false;

            do
            {
                Escribir(mensaje);
                string input = Console.ReadLine()!;

                if (decimal.TryParse(input, out numero))
                {
                    valido = true;
                }
                else
                {
                    Escribir("Entrada no válida. Por favor, introduzca un número decimal.");
                }
            } while (!valido);

            return numero;
        }

        public static string LeerTexto(string mensaje)
        {
            Escribir(mensaje);
            return Console.ReadLine()!.Trim().ToLower();
        }
    }
}

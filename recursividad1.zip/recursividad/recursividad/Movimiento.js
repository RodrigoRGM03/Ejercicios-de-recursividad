// Ejercicio 1: Factorial
function calcularFactorial() {
    const numero = document.getElementById('inputFactorial').value;
    if (numero >= 0) {
        let resultado = 1;
        for (let i = 2; i <= numero; i++) {
            resultado *= i;
        }
        document.getElementById('resultadoFactorial').innerHTML = `El factorial de ${numero} es: ${resultado}`;
    } else {
        document.getElementById('resultadoFactorial').innerHTML = "Ingrese un número positivo.";
    }
}

// Ejercicio 2: Fibonacci
function calcularFibonacci() {
    const n = document.getElementById('inputFibonacci').value;
    let fib = [0, 1];
    for (let i = 2; i < n; i++) {
        fib[i] = fib[i-1] + fib[i-2];
    }
    document.getElementById('resultadoFibonacci').innerHTML = `Serie Fibonacci (${n} términos): ${fib.join(", ")}`;
}

// Ejercicio 3: MCD
function calcularMCD() {
    const a = document.getElementById('inputMCD1').value;
    const b = document.getElementById('inputMCD2').value;

    function mcd(a, b) {
        return b === 0 ? a : mcd(b, a % b);
    }

    const resultado = mcd(a, b);
    document.getElementById('resultadoMCD').innerHTML = `El MCD de ${a} y ${b} es: ${resultado}`;
}

// Ejercicio 4: Cambio de Monedas
function calcularCambio() {
    const denominaciones = [100, 50, 20, 10, 5, 1, 0.50, 0.20, 0.01];
    let cantidad = parseFloat(document.getElementById('inputCambio').value);
    let resultado = '';

    if (cantidad > 0) {
        denominaciones.forEach(denominacion => {
            const cantidadDeMonedas = Math.floor(cantidad / denominacion);
            if (cantidadDeMonedas > 0) {
                resultado += `${cantidadDeMonedas} monedas/billetes de ${denominacion.toFixed(2)} pesos.<br>`;
                cantidad -= cantidadDeMonedas * denominacion;
            }
        });
        document.getElementById('resultadoCambio').innerHTML = resultado;
    } else {
        document.getElementById('resultadoCambio').innerHTML = 'Ingrese una cantidad válida.';
    }
}

// Ejercicio 5: Torres de Hanói
function resolverTorresDeHanoi() {
    const numeroDeDiscos = document.getElementById('inputDiscos').value;
    const resultado = [];
    moverTorres(numeroDeDiscos, 'Origen', 'Destino', 'Auxiliar', resultado);
    document.getElementById('resultadoHanoi').innerHTML = resultado.join("<br>");
}

function moverTorres(discos, origen, destino, auxiliar, resultado) {
    if (discos == 1) {
        resultado.push(`Mover disco de ${origen} a ${destino}`);
    } else {
        moverTorres(discos - 1, origen, auxiliar, destino, resultado);
        resultado.push(`Mover disco de ${origen} a ${destino}`);
        moverTorres(discos - 1, auxiliar, destino, origen, resultado);
    }
}

// Ejercicio 6: Permutaciones
function generarPermutaciones() {
    const str = document.getElementById('inputPermutacion').value;
    const resultado = [];
    permutar(str, '', resultado);
    document.getElementById('resultadoPermutacion').innerHTML = resultado.join('<br>');
}

function permutar(str, perm, resultado) {
    if (str.length === 0) {
        resultado.push(perm);
    } else {
        for (let i = 0; i < str.length; i++) {
            const currentChar = str[i];
            const remainingChars = str.slice(0, i) + str.slice(i + 1);
            permutar(remainingChars, perm + currentChar, resultado);
        }
    }
}
function salir() {
    window.close();
}

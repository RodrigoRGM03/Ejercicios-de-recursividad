using System;
using System.Collections.Generic;
using Utilities;

namespace recursividad
{
    public class Ejercicio6
    {
        public void GenerarPermutaciones(string str, string perm = "")
        {
            if (str.Length == 0)
            {
                ConsoleUtils.Escribir(perm);
            }
            else
            {
                for (int i = 0; i < str.Length; i++)
                {
                    char currentChar = str[i];

                    string remainingChars = str.Substring(0, i) + str.Substring(i + 1);

                    GenerarPermutaciones(remainingChars, perm + currentChar);
                }
            }
        }
    }
}

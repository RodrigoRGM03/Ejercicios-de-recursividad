using System.IO.Pipes;
using System.Numerics;
using Utilities;

namespace recursividad;

public abstract class FibonacciCalculo
{
    public abstract long ObtenerNumeroFibonacci(int posicion);
}


class Fibonacci : FibonacciCalculo
{

    private Dictionary<int, long> _memo = new Dictionary<int, long>();
   

    public override long ObtenerNumeroFibonacci(int posicion)
    {
        long resultado;

        if (posicion < 0)
        {
            throw new ArgumentException("La posicion no puede ser negativa");
        }

        if (_memo.ContainsKey(posicion))
        {
            return _memo[posicion];
        }

        if (posicion == 0)
        {
            resultado = 0;
        }
        else if (posicion == 1)
        {
            resultado = 1;
        }
        else
        {
            resultado = ObtenerNumeroFibonacci(posicion - 1) + ObtenerNumeroFibonacci(posicion - 2);
        }

        _memo[posicion] = resultado;
        return resultado;
    }

     public void preguntarfibo()
    {
        string entrada = ConsoleUtils.LeerTexto("Ingrese el número de términos de la serie de Fibonacci que desea ver: ");

        if (int.TryParse(entrada, out int n) && n > 0)
        {
             ConsoleUtils.Escribir("Serie de Fibonacci:");
                for (int i = 0; i < n; i++)
                {
                    ConsoleUtils.Escribir($"{ObtenerNumeroFibonacci(i)} "); //SE LLAMA AL METODO OBTENER NUMERO FIBONACCI
                }
        }
        else
        {
            ConsoleUtils.Escribir("Por favor, ingrese un número entero positivo válido.");
        }
    }
}
using System;
using Utilities; 

namespace recursividad
{
    public class TorresDeHanoi
    {
        public void Resolver(int numeroDeDiscos)
        {
            MoverTorres(numeroDeDiscos, "Origen", "Destino", "Auxiliar");
        }

        private void MoverTorres(int discos, string origen, string destino, string auxiliar)
        {
            if (discos == 1)
            {
                ConsoleUtils.Escribir($"Mover disco de {origen} a {destino}");
            }
            else
            {
                MoverTorres(discos - 1, origen, auxiliar, destino);
                ConsoleUtils.Escribir($"Mover disco de {origen} a {destino}");
                MoverTorres(discos - 1, auxiliar, destino, origen);
            }
        }
    }
}

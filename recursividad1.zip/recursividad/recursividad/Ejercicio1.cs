using System.Numerics;
using Utilities;

namespace recursividad;

public abstract class FactorialCalculo
{
    public abstract BigInteger CalcularFactorial(int numero);
}

class Factorial : FactorialCalculo
{
      public override BigInteger CalcularFactorial(int numero)
        {
            if (numero < 0)
            {
                throw new ArgumentException("El número no puede ser negativo ingrese un valor positivo");
            }

            BigInteger resultado = 1;  

            for (int i = 2; i <= numero; i++)
            {
                resultado *= i;
            }

            return resultado;
        }

      public void Preguntar()
        {
            bool continuar = true;

            while (continuar)
            {
                Console.Clear();
                ConsoleUtils.Escribir("=== Factorial ===");
                string input = ConsoleUtils.LeerTexto("Por favor ingrese el número a calcular (o escriba 'salir' para regresar al menú principal):");

                if (input == "salir")
                {
                    continuar = false;
                    continue;
                }

                if (int.TryParse(input, out int numero))
                {
                    try
                    {
                        BigInteger resultado = CalcularFactorial(numero);
                        Console.WriteLine($"El factorial de {numero} es: {resultado}");
                    }
                    catch (ArgumentException ex)
                    {
                        Console.WriteLine($"Error: {ex.Message}");
                    }
                }
                else
                {
                    Console.WriteLine("Error: Debes ingresar un número entero válido o 'salir' para regresar.");
                }

                
                while (true)
                {
                    string respuesta = ConsoleUtils.LeerTexto("¿Desea calcular otro factorial? (s/n):");

                    if (respuesta == "s")
                    {
                        break;
                    }
                    else if (respuesta == "n" || respuesta == "salir")
                    {
                        continuar = false;
                        break;
                    }
                    else
                    {
                        ConsoleUtils.Escribir("Entrada no válida. Por favor, ingrese 's' para sI o 'n' para no");
                    }
                }
            }
        }
    }
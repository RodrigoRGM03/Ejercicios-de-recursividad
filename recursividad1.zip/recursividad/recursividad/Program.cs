﻿using System;
using Utilities;

namespace recursividad
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            while (!exit)
            {
                ConsoleUtils.Escribir("=== Menú de Problemas Recursivos ===");
                ConsoleUtils.Escribir("1. Ejercicio 1: Factorial");
                ConsoleUtils.Escribir("2. Ejercicio 2: Fibonaccí");
                ConsoleUtils.Escribir("3. Ejercicio 3: MInimo Comun Divisor");
                ConsoleUtils.Escribir("4. Ejercicio 4: Cambio de Monedas");
                ConsoleUtils.Escribir("5. Ejercicio 5: Torres de Hanói");
                ConsoleUtils.Escribir("6. Ejercicico 6: Permutación");
                ConsoleUtils.Escribir("7. Salir");

                int opcion = ConsoleUtils.LeerNumero("Seleccione una opción: ");

                switch (opcion)
                {
                    case 1:
                        Factorial fac = new Factorial();
                        fac.Preguntar();
                        break;
                    case 2:
                        Fibonacci fibo = new Fibonacci();
                        fibo.preguntarfibo();
                        break;
                    case 3:
                        EjercicioMCD ejercicioMCD = new EjercicioMCD();
                        int numero1 = ConsoleUtils.LeerNumero("Introduce el primer número para calcular el MCD: ");
                        int numero2 = ConsoleUtils.LeerNumero("Introduce el segundo número para calcular el MCD: ");
                        int resultadoMCD = ejercicioMCD.CalcularMCD(numero1, numero2);
                        ConsoleUtils.Escribir($"El MCD de {numero1} y {numero2} es: {resultadoMCD}");
                        break;
                    case 4:
                        Ejercicio4 ejercicio4 = new Ejercicio4(); 
                        ejercicio4.ResolverCambio(); 
                        break;
                    case 5:
                        TorresDeHanoi hanoi = new TorresDeHanoi(); 
                        int discos = ConsoleUtils.LeerNumero("Introduce el número de discos: ");
                        hanoi.Resolver(discos); 
                        break;
                    case 6:
                        Ejercicio6 ejercicio6 = new Ejercicio6();
                        string cadena = ConsoleUtils.LeerTexto("Introduce la cadena para generar permutaciones: ");
                        ConsoleUtils.Escribir($"Las permutaciones de la cadena '{cadena}' son:");
                        ejercicio6.GenerarPermutaciones(cadena);
                        break;
                    case 7:
                        exit = true;
                        ConsoleUtils.Escribir("Saliendo...");
                        break;
                    default:
                        ConsoleUtils.Escribir("Opción no válida, intente de nuevo.");
                        break;
                }

                if (!exit)
                {
                    ConsoleUtils.Escribir("Presione cualquier tecla para continuar...");
                    Console.ReadKey();
                    Console.Clear();
                }
            }
        }
    }
}

using System;
using Utilities;

namespace recursividad
{
    public class Ejercicio4
    {
        static readonly decimal[] denominaciones = { 100m, 50m, 20m, 10m, 5m, 1m, 0.50m, 0.20m, 0.01m };

        public void ResolverCambio()
        {
            decimal cantidad = ConsoleUtils.LeerDecimal("Introduce la cantidad a devolver: ");
            CalcularMonedas(cantidad, 0);
        }

        private void CalcularMonedas(decimal cantidad, int index)
        {
            if (index >= denominaciones.Length || cantidad == 0)
            {
                return;
            }

            decimal denominacionActual = denominaciones[index];
            int cantidadDeMonedas = (int)(cantidad / denominacionActual);

            if (cantidadDeMonedas > 0)
            {
                ConsoleUtils.Escribir($"{cantidadDeMonedas} monedas/billetes de {denominacionActual} pesos.");
                cantidad -= cantidadDeMonedas * denominacionActual;
            }

            CalcularMonedas(cantidad, index + 1);
        }
    }
}
